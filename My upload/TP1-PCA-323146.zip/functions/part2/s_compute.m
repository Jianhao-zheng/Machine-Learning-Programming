function size=s_compute(X)
size=numel(X)*64;
end

